# -*- coding: utf-8 -*-

#########################################################################

from gluon.tools import *
mail = Mail()                                  # mailer
auth = Auth(globals(),db)                      # authentication/authorization
crud = Crud(globals(),db)                      # for CRUD helpers using auth
service = Service(globals())                   # for json, xml, jsonrpc, xmlrpc, amfrpc
plugins = PluginManager()

mail.settings.server = 'logging' or 'smtp.gmail.com:587'  # your SMTP server
mail.settings.sender = 'you@gmail.com'         # your email
mail.settings.login = 'username:password'      # your credentials or None

auth.settings.hmac_key = 'sha512:d6160708-08e3-4217-bd9e-e9a550109a8d'   # before define_tables()
#auth.define_tables()                           # creates all needed tables
auth.settings.mailer = mail                    # for user email verification
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.messages.verify_email = 'Click on the link http://'+request.env.http_host+URL('default','user',args=['verify_email'])+'/%(key)s to verify your email'
auth.settings.reset_password_requires_verification = True
auth.messages.reset_password = 'Click on the link http://'+request.env.http_host+URL('default','user',args=['reset_password'])+'/%(key)s to reset your password'

#########################################################################

crud.settings.auth = None                      # =auth to enforce authorization on crud

#########################################################################
# Common Variable
#mreporting_http_pass='abC321'
# ' " / \ < > ( ) [ ] { } ,

#======================date========================
import datetime
import os

datetime_fixed=str(date_fixed)[0:19]    # default datetime 2012-07-01 11:48:10
current_date=str(date_fixed)[0:10]   # default date 2012-07-01

first_currentDate = datetime.datetime.strptime(str(current_date)[0:7] + '-01', '%Y-%m-%d')

#================smsGateway Database===================
#--------------------------- signature
signature=db.Table(db,'signature',
                Field('field1','string',default=''), 
                Field('field2','integer',default=0),
                Field('note','string',default=''),  
                Field('created_on','datetime',default=date_fixed),
                Field('created_by',default=session.user_id),
                Field('updated_on','datetime',update=date_fixed),
                Field('updated_by',update=session.user_id),
                )

#=====================leave Table================
db.define_table('inbox',
                Field('cid','string',requires=IS_NOT_EMPTY(),default=session.cid),
                Field('from_number','string',requires=IS_NOT_EMPTY()),
                Field('message','string',requires=IS_NOT_EMPTY()),
                Field('res_datetime','datetime',requires=IS_NOT_EMPTY()),

                signature,
                migrate=True
                )
